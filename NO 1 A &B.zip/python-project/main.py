tgl_lahir_tweedledoom = (1861, 10, 23)
tgl_lahir_tweedledee = (1861, 10, 23)

kemampuan_tweedledoom = {"Bersyair", "Menyanyi", "Suka Berpura-pura"}
kemampuan_tweedledee = {"Bersyair", "Menyanyi", "Suka Berpura-pura"}
kemampuan_tweedledee = {"Bersyair", "Menyanyi", "Suka Berpura-pura"}

kemampuan_tweedledee.remove("Bersyair")
kemampuan_tweedledee.add("Memanah")

print(kemampuan_tweedledee)
