hari_pertama = {"keju", "tepung", "garam", "gula", "coklat"}
hari_kedua = {"garam", "gula", "coklat", "kecap"}

hari_kedua.add("keju")

sama = hari_pertama & hari_kedua
print("Barang yang sama:", sama)

hanya_hari_pertama = hari_pertama - hari_kedua
print("Hari pertama saja:", hanya_hari_pertama)

hari_pertama.remove("garam")

hanya_hari_kedua = hari_kedua - hari_pertama
print("Hari kedua saja:", hanya_hari_kedua)

tidak_sama = hari_pertama ^ hari_kedua
print("Barang yang tidak sama:", tidak_sama)

print("Semua pembelian hari pertama:")
for item in hari_pertama:
    print("-", item)

print("Semua pembelian hari kedua:")
for item in hari_kedua:
    print("-", item)
